<?php
namespace Database\Seeders;
use Illuminate\Database\Seeder;
use App\Models\User;

class UserSeeder extends Seeder
{
    public function run()
    {
        $departments = [1, 2, 6, 7];
        $roles = [1, 2];
        $companyId = 1;

        foreach ($departments as $departmentId) {
            foreach ($roles as $roleId) {
                User::create([
                    'company_id' => $companyId,
                    'role_id' => $roleId,
                    'department_id' => $departmentId,
                    'password' => bcrypt('password123'),
                    'user_code' => 'USR' . rand(1000, 9999),
                    'additional_information' => 'Generated User',
                    'first_name' => 'John',
                    'second_name' => 'Doe',
                    'middle_name' => 'A.',
                    'last_name' => 'Smith',
                    'image_path' => null,
                    'national_id' => rand(100000, 999999),
                    'marital_status' => 'Single',
                    'attendtaby' => 'any location',
                    'date_of_birth' => '1990-01-01',
                    'holidays' => 10,
                    'salary' => 5000,
                    'sick_days' => 5,
                    'annual_vacations_days' => 20,
                ]);
            }
        }
    }
}
