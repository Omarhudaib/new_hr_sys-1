<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class CheckInSeeder extends Seeder
{
    public function run()
    {
        // Define department locations
        $locations = [
            'HR' => ['latitude' => 34.0523, 'longitude' => -118.2438],
            'IT' => ['latitude' => 34.0522, 'longitude' => -118.2437],
        ];

        // Define users (ID and department)
        $users = [];
        for ($id = 12; $id <= 29; $id++) {
            $users[] = [
                'id' => $id,
                'department' => rand(0, 1) ? 'IT' : 'HR', // Randomly assign HR or IT
                'role' => rand(0, 1) ? 'Admin' : 'Employee',
            ];
        }

        // Get start and end dates (2 years)
        $startDate = Carbon::now()->subYears(50);
        $endDate = Carbon::now();

        // Generate check-in records for each user
        foreach ($users as $user) {
            for ($date = $startDate->copy(); $date <= $endDate; $date->addDay()) {
                if ($date->isWeekend()) continue; // Skip weekends

                $checkInTime = $date->copy()->setTime(rand(8, 10), rand(0, 59));
                $checkOutTime = $date->copy()->setTime(rand(17, 19), rand(0, 59));

                // Admins get randomized locations
                $location = $user['role'] === 'Admin'
                    ? [
                        'latitude' => rand(340000000, 349999999) / 10000000,
                        'longitude' => rand(-1189999999, -1180000000) / 10000000,
                    ]
                    : $locations[$user['department']];

                // Insert check-in data
                DB::table('check_ins')->insert([
                    'company_id' => 1,
                    'user_id' => $user['id'],
                    'check_in' => $checkInTime,
                    'location_in' => 'Building ' . ($user['department'] === 'IT' ? 1 : 2),
                    'latitude_in' => $location['latitude'],
                    'longitude_in' => $location['longitude'],
                    'check_out' => $checkOutTime,
                    'location_out' => 'Building ' . ($user['department'] === 'IT' ? 1 : 2),
                    'latitude_out' => $location['latitude'],
                    'longitude_out' => $location['longitude'],
                    'created_at' => now(),
                    'updated_at' => now(),
                ]);
            }
        }
    }
}
