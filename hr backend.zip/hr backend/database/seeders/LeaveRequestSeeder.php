<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\LeaveRequest;
use Carbon\Carbon;

class LeaveRequestSeeder extends Seeder
{
    public function run()
    {
        $leaveTypes = [5, 6, 7];
        $users = [1, 2, 3, 4, 5];
        $companyId = 1;

        foreach ($users as $userId) {
            foreach ($leaveTypes as $leaveTypeId) {
                LeaveRequest::create([
                    'company_id' => $companyId,
                    'user_id' => $userId,
                    'leave_type_id' => $leaveTypeId,
                    'start_date' => Carbon::now()->subDays(rand(1, 30)), // Random past date
                    'end_date' => Carbon::now()->addDays(rand(1, 15)),  // Random future date
                    'status' => 'Pending', // Example status
                    'reason' => 'Test leave request for seeder data',
                    'image_path' => null, // Set to a path if needed
                ]);
            }
        }
    }
}
