<?php
use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\Auth\RegisterController;
use App\Http\Controllers\CheckInsController;
use App\Http\Controllers\CompanyController;
use App\Http\Controllers\DepartmentController;
use App\Http\Controllers\LeaveRequestController;
use App\Http\Controllers\LeaveTypeController;
use App\Http\Controllers\RoleController;
use App\Http\Controllers\UserController;
use Illuminate\Support\Facades\Route;

Route::get('/superadmin/companies',[CompanyController::class,'indexCompany']);
Route::put('/superadmin/companies',[CompanyController::class,'updateCompany']);
Route::post('/superadmin/companies',[CompanyController::class,'storeCompany']);
Route::post('/user-login',[LoginController::class,'loginUser']);
Route::post('/user-checkIn/{id}', [CheckInsController::class, 'checkIn']);
Route::post('/user-checkOut/{id}', [CheckInsController::class, 'checkOut']);

Route::get('/user-checkStatus/{id}', [CheckInsController::class, 'checkStatus']);
Route::post('/register', [RegisterController::class, 'register']);

Route::post('/login', [LoginController::class, 'loginCompany']);
// Ensure your login method is correct in LoginController
Route::post('/logout', [LoginController::class, 'logout'])->middleware('auth:sanctum'); // Logout route with Sanctum auth middleware
  Route::post('/user-checkIn/{id}', [CheckInsController::class, 'checkIn']);
    Route::post('/user-checkOut/{id}', [CheckInsController::class, 'checkOut']);

    Route::get('/user-checkStatus/{id}', [CheckInsController::class, 'checkStatus']);
 // Registration route

Route::middleware(['auth:sanctum'])->group(function () {
    // List all users for the same company as the authenticated user
    Route::get('/usersc/{company_code}', [UserController::class, 'index']);

    // Show a specific user
    Route::get('/users/{company_code}/{id}', [UserController::class, 'show']);

    // Create a new user under the same company as the authenticated user
    Route::post('/users/{company_code}', [UserController::class, 'store']);

    // Update a user only if they belong to the same company as the authenticated user
    Route::put('users/{company_code}/{id}', [UserController::class, 'update']);

    // Delete a user only if they belong to the same company as the authenticated user
    Route::delete('/users/{id}', [UserController::class, 'destroy']);

    //Route::get('/company/{companyCode}/roles', [UserController::class, 'index']);
    Route::get('leave_types/{companyCode}', [LeaveTypeController::class, 'index']);  // Get leave types for a specific company
    Route::get('leave_types/{companyCode}/{id}', [LeaveTypeController::class, 'show']);  // Get a specific leave type by ID
    Route::post('leave_types/{companyCode}', [LeaveTypeController::class, 'store']);  // Create a new leave type
    Route::put('leave_types/{companyCode}/{id}', [LeaveTypeController::class, 'update']);  // Update a leave type by ID
    Route::delete('leave_types/{companyCode}/{id}', [LeaveTypeController::class, 'destroy']);  // Delete a leave type by ID

// Define routes for leave requests with companyCode as a parameter
Route::get('leave_requests/{companyCode}', [LeaveRequestController::class, 'index']);
Route::post('leave_requests/{companyCode}', [LeaveRequestController::class, 'store']);
Route::put('leave_requests/{companyCode}/{id}', [LeaveRequestController::class, 'update']);
Route::delete('leave_requests/{companyCode}/{id}', [LeaveRequestController::class, 'destroy']);


    Route::get('/role/{companyCode}', [RoleController::class, 'index']);
    Route::post('/roles/{companyCode}', [RoleController::class, 'store']);
    Route::put('/roles/{companyCode}/{id}', [RoleController::class, 'update']);
    Route::delete('/roles/{companyCode}/{id}', [RoleController::class, 'destroy']);
    Route::get('/roles/{companyCode}/{id}', [RoleController::class, 'show']);

    Route::get('/departments/{companyCode}', [DepartmentController::class, 'index']);
    Route::post('/departments/{companyCode}', [DepartmentController::class, 'store']); // Add department
    Route::get('/department/{companyCode}/{id}', [DepartmentController::class, 'show']); // View department
    Route::put('/departments/{companyCode}/{id}', [DepartmentController::class, 'update']); // Edit department
    Route::delete('/departments/{companyCode}/{id}', [DepartmentController::class, 'destroy']); // Delete department

// Existing routesdailyCheckIns\

// Routes file (api.php or web.php)
Route::get('/checkins/dailyCheckIns/{companyCode}', [CheckInsController::class, 'dailyCheckIns']);
Route::get('/checkins/{companyCode}', [CheckInsController::class, 'index']); // List all check-ins for a specific company
Route::get('/checkins/user/{companyCode}/{id}', [CheckInsController::class, 'userCheckIns']); // List check-ins for a specific user in a company

Route::get('/checkin/user/m/{companyCode}/{userId}', [CheckInsController::class, 'CheckInUser']);
Route::post('/checkins/{companyCode}', [CheckInsController::class, 'store']); // Create a new check-in for a company
Route::get('/checkins/{companyCode}/{id}', [CheckInsController::class, 'show']); // Show a specific check-in
Route::put('/checkins/{companyCode}/{id}', [CheckInsController::class, 'update']); // Update a check-in
Route::delete('/checkins/{companyCode}/{id}', [CheckInsController::class, 'destroy']); // Delete a check-in

// New routes
Route::post('/checkins/summary/{companyCode}/{standardHours}/{Month}/{Year}', [CheckInsController::class, 'summary']);
Route::post('/checkins/{companyCode}/bulk-upload', [CheckInsController::class, 'bulkUpload']); // Bulk upload check-ins
Route::get('/checkins/{companyCode}/filter', [CheckInsController::class, 'filterByUserAndDate']); // Filter check-ins by user and date range

Route::get('/company/{companyCode}', [CompanyController::class, 'index']);
Route::put('/company/{companyCode}', [CompanyController::class, 'update']);




    Route::post('/user-submitRequest/{id}', [LeaveRequestController::class, 'submitRequest']);

    Route::get('/user-Request/{id}', [LeaveRequestController::class, 'UserRequest']);

    Route::get('/leave-types/{company_id}', [LeaveTypeController::class, 'leavetypesu']);
});

