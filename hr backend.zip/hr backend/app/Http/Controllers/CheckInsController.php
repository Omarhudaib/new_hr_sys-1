<?php
namespace App\Http\Controllers;
use App\Models\CheckIn;
use App\Models\Company;
use App\Models\Department;
use App\Models\LeaveRequest;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use PhpParser\Node\Stmt\Else_;

class CheckInsController extends Controller
{
    public function summary(Request $request, $companyCode, $standardHours, $month, $year)
    {
        // Fetch the company details
        $company = Company::where('company_code', $companyCode)->first();

        if (!$company) {
            Log::error('Company not found for code: ' . $companyCode);
            return response()->json(['error' => 'Company not found'], 404);
        }

        // Override company standard hours with the passed parameter
        $standardHours = $standardHours ?? $company->standard_hours ?? 8;

        // Get users in the company
        $users = User::where('company_id', $company->id)
            ->get(['id', 'first_name', 'second_name', 'middle_name', 'last_name']);

        if ($users->isEmpty()) {
            return response()->json(['message' => 'No users found for this company'], 404);
        }

        // Use the passed month and year
        $summary = CheckIn::whereIn('user_id', $users->pluck('id'))
            ->whereMonth('check_in', $month)
            ->whereYear('check_in', $year)
            ->select([
                'user_id',
                DB::raw('SUM(TIMESTAMPDIFF(HOUR, check_in, check_out)) as total_hours'),
                DB::raw('COUNT(*) as total_check_ins'),
                DB::raw("SUM(GREATEST(0, TIMESTAMPDIFF(HOUR, check_in, check_out) - {$standardHours})) as overtime_hours"),
                DB::raw("SUM(GREATEST(0, {$standardHours} - TIMESTAMPDIFF(HOUR, check_in, check_out))) as delay_hours"),
            ])
            ->groupBy('user_id')
            ->get();

        // Combine summary data with user details
        $result = $users->map(function ($user) use ($summary) {
            $userSummary = $summary->firstWhere('user_id', $user->id);

            return [
                'user_id' => $user->id,
                'user_name' => trim("{$user->first_name} {$user->second_name} {$user->middle_name} {$user->last_name}"),
                'total_hours' => $userSummary->total_hours ?? 0,
                'total_check_ins' => $userSummary->total_check_ins ?? 0,
                'overtime_hours' => $userSummary->overtime_hours ?? 0,
                'delay_hours' => $userSummary->delay_hours ?? 0,
            ];
        });

        return response()->json($result);
    }


public function CheckInUser(Request $request, $companyCode, $userId)
{
    $month = $request->query('month');
    $year = $request->query('year');

    // البحث عن الشركة باستخدام الكود
    $company = Company::where('company_code', $companyCode)->first();

    // إذا لم يتم العثور على الشركة، إرجاع خطأ
    if (!$company) {
        return response()->json(['error' => 'Company not found'], 404);
    }

    // إنشاء تواريخ البداية والنهاية للشهر المطلوب
    $startDate = $year . '-' . str_pad($month, 2, '0', STR_PAD_LEFT) . '-01';
    $endDate = date('Y-m-t', strtotime($startDate)); // آخر يوم في الشهر

    // جلب السجلات من جدول CheckIn
    $checkIns = CheckIn::where('company_id', $company->id)
        ->where('user_id', $userId)
        ->whereBetween('check_in', [$startDate . ' 00:00:00', $endDate . ' 23:59:59']) // حدد المدى الزمني
        ->get()
        ->groupBy(function ($item) {
            return substr($item->check_in, 0, 10); // تجميع حسب التاريخ فقط
        });

    // إنشاء قائمة بكل تواريخ الشهر
    $datesInMonth = [];
    $daysInMonth = (int)date('t', strtotime($startDate));
    for ($day = 1; $day <= $daysInMonth; $day++) {
        $datesInMonth[] = $year . '-' . str_pad($month, 2, '0', STR_PAD_LEFT) . '-' . str_pad($day, 2, '0', STR_PAD_LEFT);
    }

    // توليد بيانات الحضور
    $attendanceData = [];
    foreach ($datesInMonth as $date) {
        if (isset($checkIns[$date])) {
            // إذا كان هناك تسجيل دخول في ذلك اليوم
            $dailyCheckIns = $checkIns[$date];
            $workHours = 0;

            // حساب عدد ساعات العمل
            foreach ($dailyCheckIns as $checkIn) {
                if ($checkIn->check_out) { // تأكد من وجود وقت الخروج
                    $startTime = strtotime($checkIn->check_in);
                    $endTime = strtotime($checkIn->check_out);
                    $workHours += ($endTime - $startTime) / 3600; // فرق الوقت بالساعات
                }
            }

            $attendanceData[] = [
                'date' => $date,
                'status' => 'Checked In',
                'work_hours' => round($workHours, 2) // تقريبه إلى منزلتين عشريتين
            ];
        } else {
            // إذا لم يكن هناك تسجيل دخول في ذلك اليوم
            $attendanceData[] = [
                'date' => $date,
                'status' => 'Off Day',
                'work_hours' => 0
            ];
        }
    }

    // إرجاع النتائج
    return response()->json(['attendance' => $attendanceData]);
}

    // Create a new check-in
    public function store(Request $request, $companyCode)
    {
        $company = Company::where('company_code', $companyCode)->first();
        if (!$company) {
            return response()->json(['error' => 'Company not found'], 404);
        }

        $request->validate([
            'user_id' => 'required|exists:users,id',
            'check_in' => 'required|date',
            'location_in' => 'required|string',
            'latitude_in' => 'nullable|numeric',
            'longitude_in' => 'nullable|numeric',
            'location_out' => 'nullable|string',
            'latitude_out' => 'nullable|numeric',
            'longitude_out' => 'nullable|numeric',
            'check_out' => 'nullable|date',
        ]);

        $checkIn = CheckIn::create(array_merge(
            $request->only([
                'user_id', 'check_in', 'location_in', 'latitude_in',
                'longitude_in', 'location_out', 'latitude_out',
                'longitude_out', 'check_out'
            ]),
            ['company_id' => $company->id]
        ));

        return response()->json($checkIn, 201);
    }

    // Show details of a specific check-in
    public function show($companyCode, $id)
    {
        $company = Company::where('company_code', $companyCode)->first();
        if (!$company) {
            return response()->json(['error' => 'Company not found'], 404);
        }

        $checkIn = CheckIn::where('company_id', $company->id)->where('id', $id)->first();

        if (!$checkIn) {
            return response()->json(['message' => 'Check-in not found'], 404);
        }

        return response()->json($checkIn);
    }


    public function update(Request $request, $companyCode, $id)



{ $company = Company::where('company_code', $companyCode)->first();
    if (!$company) {
        return response()->json(['error' => 'Company not found'], 404);
    }
    $checkIn = CheckIn::where('company_id', $company->id)->where('id', $id)->first();

    if (!$checkIn) {
        return response()->json(['message' => 'Check-in not found'], 404);
    }

    $request->validate([
        'user_id' => 'required|exists:users,id',
        'check_in' => 'required|date',
        'location_in' => 'required|string',
        'latitude_in' => 'nullable|numeric',
        'longitude_in' => 'nullable|numeric',
        'location_out' => 'nullable|string',
        'latitude_out' => 'nullable|numeric',
        'longitude_out' => 'nullable|numeric',
        'check_out' => 'nullable|date',
    ]);

    $checkIn->update($request->all());

    return response()->json($checkIn);
}


    // Delete a check-in
    public function destroy($companyCode, $id)
    {
        $company = Company::where('company_code', $companyCode)->first();
        if (!$company) {
            return response()->json(['error' => 'Company not found'], 404);
        $checkIn = CheckIn::where('company_id', $company->id)->find($id);

        if (!$checkIn) {
            return response()->json(['message' => 'Check-in not found'], 404);
        }

        $checkIn->delete();

        return response()->json(['message' => 'Check-in deleted successfully']);
    }
}


public function index(Request $request, $companyCode)
{
    // Find the company by its company_code
    $company = Company::where('company_code', $companyCode)->first();

    // If the company doesn't exist, return an error response
    if (!$company) {
        return response()->json(['error' => 'Company not found'], 404);
    }

    // Start the query for CheckIns associated with the company
    $query = CheckIn::where('company_id', $company->id);

    // Apply filters based on request parameters
    if ($request->has('start_date') && $request->has('end_date')) {
        $query->whereBetween('check_in', [$request->start_date, $request->end_date]);
    }

    if ($request->has('month')) {
        $month = $request->month;
        $query->whereMonth('check_in', '=', date('m', strtotime($month)))
              ->whereYear('check_in', '=', date('Y', strtotime($month)));
    }

    if ($request->has('user_id')) {
        $query->where('user_id', $request->user_id);
    }

    if ($request->has('department')) {
        $query->where('department_id', $request->department);
    }

    if ($request->has('check_in_time')) {
        $query->where('check_in', '>=', $request->check_in_time);
    }

    if ($request->has('check_out_time')) {
        $query->where('check_out', '<=', $request->check_out_time);
    }

    // Paginate the result
    $checkIns = $query->paginate(10);

    return response()->json($checkIns);
}

public function dailyCheckIns(Request $request, $companyCode)
{
    // Find the company by its company_code
    $company = Company::where('company_code', $companyCode)->first();

    // If the company doesn't exist, return an error response
    if (!$company) {
        return response()->json(['error' => 'Company not found'], 404);
    }

    // Start the query for CheckIns associated with the company
    $query = CheckIn::where('company_id', $company->id);

    // Filter by the current date or a provided 'date'
    $date = $request->input('date', now()->toDateString());
    $query->whereDate('check_in', $date);

    // Execute the query to get the results with pagination
    $checkIns = $query->paginate(10);

    // Return the paginated check-ins as JSON response
    return response()->json($checkIns);
}




// Filter check-ins by user and date range
public function filterByUserAndDate(Request $request, $companyCode)
{
    $company = Company::where('company_code', $companyCode)->first();
    if (!$company) {
        return response()->json(['error' => 'Company not found'], 404);
    }

    $query = CheckIn::where('company_id', $company->id);

    if ($request->has('user_id')) {
        $query->where('user_id', $request->user_id);
    }

    if ($request->has('start_date') && $request->has('end_date')) {
        $query->whereBetween('check_in', [
            Carbon::parse($request->start_date),
            Carbon::parse($request->end_date),
        ]);
    }

    $checkIns = $query->get();

    return response()->json($checkIns);
}
public function checkIn(Request $request, $id)
{
    // Fetch the user by their ID
    $user = User::find($id);

    if (!$user) {
        return response()->json(['error' => 'User not found'], 404);
    }

    // Ensure the user hasn't already checked in today **without checking out**
    $today = now()->format('Y-m-d');
    $existingCheckIn = CheckIn::where('user_id', $id)->whereDate('check_in', $today)->latest()->first();

    if ($existingCheckIn && is_null($existingCheckIn->check_out)) {
        return response()->json(['error' => 'You have already checked in today without checking out'], 404);
    }

    // If the user's check-in is based on department location
    if ($user->attendtaby == 'dep location') {
        $department = Department::where('id', $user->department_id)->first();

        if (!$department) {
            return response()->json(['error' => 'No department found for this user'], 480);
        }

        $latitude = $request->input('latitude_in');
        $longitude = $request->input('longitude_in');

        if (!is_numeric($latitude) || !is_numeric($longitude)) {
            return response()->json(['error' => 'Invalid location format. Latitude and Longitude must be numeric.'], 490);
        }

        if (!$latitude || !$longitude) {
            return response()->json(['error' => 'Invalid location format. Provide latitude and longitude.'], 450);
        }

        // Calculate the distance between the department and the check-in location
        $distance = $this->haversineGreatCircleDistance($department->latitude, $department->longitude, $latitude, $longitude);
        $acceptableDistance = 0.1; // 100 meters in kilometers

        Log::info("Calculated distance: " . $distance);

        if ($distance > $acceptableDistance) {
            return response()->json(['error' => 'Location too far from expected location'], 470);
        }
    }

    // Create the check-in record
    $checkIn = CheckIn::create([
        'company_id' => $user->company_id,
        'user_id' => $id,
        'check_in' => now(),
        'location_in' => $request->input('location_in'),
        'latitude_in' => $request->input('latitude_in'),
        'longitude_in' => $request->input('longitude_in'),
    ]);

    return response()->json(['success' => 'Checked in successfully', 'data' => $checkIn], 200);
}


public function checkOut(Request $request, $id)
{
    $user = User::find($id);
    if (!$user) {
        return response()->json(['error' => 'User not found'], 404);
    }

    $lastCheckIn = CheckIn::where('user_id', $id)->latest()->first();
    if (!$lastCheckIn) {
        return response()->json(['error' => 'No check-in record found'], 400);
    }

    if ($lastCheckIn->check_out) {
        return response()->json(['error' => 'You have already checked out'], 400);
    }

    if ($user->attendtaby == 'dep location') {
        $department = Department::where('id', $user->department_id)->first();

        if (!$department) {
            return response()->json(['error' => 'No department found for this user'], 400);
        }

        $latitude = $request->input('latitude_out');
        $longitude = $request->input('longitude_out');

        // Validate latitude and longitude
        if (!is_numeric($latitude) || !is_numeric($longitude)) {
            return response()->json(['error' => 'Invalid location format. Latitude and Longitude must be numeric.'], 400);
        }

        if (!$latitude || !$longitude) {
            return response()->json(['error' => 'Invalid location format. Provide latitude and longitude.'], 400);
        }

        // Calculate the distance between the department and the check-out location
        $distance = $this->haversineGreatCircleDistance($department->latitude, $department->longitude, $latitude, $longitude);
        $acceptableDistance = 0.1; // 100 meters in kilometers

        // Log the calculated distance for debugging purposes
        Log::info("Calculated distance: " . $distance);

        if ($distance > $acceptableDistance) {
            return response()->json(['error' => 'Location too far from expected location'], 400);
        }
    }

    $lastCheckIn->update([
        'check_out' => now(),
        'location_out' => $request->input('location_out'),
        'latitude_out' => $request->input('latitude_out'),
        'longitude_out' => $request->input('longitude_out'),
    ]);

    return response()->json(['success' => 'Checked out successfully', 'data' => $lastCheckIn], 200);
}


    private function haversineGreatCircleDistance($lat1, $lon1, $lat2, $lon2, $earthRadius = 6371)
    {
        $lat1 = deg2rad($lat1);
        $lon1 = deg2rad($lon1);
        $lat2 = deg2rad($lat2);
        $lon2 = deg2rad($lon2);

        $dLat = $lat2 - $lat1;
        $dLon = $lon2 - $lon1;

        $a = sin($dLat / 2) * sin($dLat / 2) +
            cos($lat1) * cos($lat2) *
            sin($dLon / 2) * sin($dLon / 2);

        $c = 2 * atan2(sqrt($a), sqrt(1 - $a));

        return $earthRadius * $c;
}
public function checkStatus($id)
{
    $user = User::find($id);
    if (!$user) {
        return response()->json(['error' => 'User not found'], 404);
    }

    $today = now()->toDateString(); // تنسيق التاريخ بشكل دقيق

    // البحث عن سجل check-in لليوم الحالي
    $checkIn = CheckIn::where('user_id', $id)
                      ->whereDate('check_in', $today)
                      ->first();

    return response()->json([
        'isCheckedIn' => (bool) $checkIn,  // إذا وجد check-in، يعني أن المستخدم دخل
        'isCheckedOut' => $checkIn && $checkIn->check_out !== null // إذا كان check_out ليس فارغًا، يعني أن المستخدم خرج
    ]);
}

}
