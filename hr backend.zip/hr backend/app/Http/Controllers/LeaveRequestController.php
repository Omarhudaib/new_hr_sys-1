<?php
namespace App\Http\Controllers;

use Illuminate\Support\Facades\Log;
use App\Models\Company;
use App\Models\LeaveRequest;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class LeaveRequestController extends Controller
{   public function submitRequest(Request $request, $id)
    {
        // Validate the incoming request data
        $validated = $request->validate([
            'user_id' => 'required|exists:users,id',
            'leave_type_id' => 'required|exists:leave_types,id',
            'start_date' => 'required|date',
            'end_date' => 'required|date|after_or_equal:start_date',
            'reason' => 'nullable|string|max:255',
        ]);

        // Assign company ID from the route parameter
        $validated['company_id'] = $id;

        // Save the leave request to the database
        $leaveRequest = LeaveRequest::create([
            'user_id' => $validated['user_id'],
            'leave_type_id' => $validated['leave_type_id'],
            'start_date' => $validated['start_date'],
            'end_date' => $validated['end_date'],
            'reason' => $validated['reason'] ?? null,
            'company_id' => $validated['company_id'],
            'status' => 'Pending', // Default status
        ]);

        // Return a success response
        return response()->json([
            'success' => true,
            'message' => 'Request submitted successfully!',
            'data' => $leaveRequest,
        ], 200);
    }

    public function UserRequest($id)
{
    $leaveRequests = LeaveRequest::where('user_id', $id)
        ->with('leaveType') // Eager load the leaveType relationship
        ->get();

    return response()->json($leaveRequests);
}


    public function index($companyCode)
    {
        $company = Company::where('company_code', $companyCode)->first();

        if (!$company) {
            return response()->json(['error' => 'Company not found'], 404);
        }

        // Include related user and leave type
        $leaveRequests = LeaveRequest::where('company_id', $company->id)
            ->with(['user', 'leaveType'])
            ->get();

        return response()->json($leaveRequests);
    }


    public function store(Request $request, $companyCode)
    {
        $company = Company::where('company_code', $companyCode)->first();

        if (!$company) {
            return response()->json(['error' => 'Company not found'], 404);
        }

        $validatedData = $request->validate([
            'user_id' => 'required|exists:users,id',
            'leave_type_id' => 'required|exists:leave_types,id',
            'start_date' => 'required|date',
            'end_date' => 'required|date|after_or_equal:start_date',
            'status' => 'required|in:Pending,Approved,Rejected',
            'reason' => 'nullable|string',
            'image_path' => 'nullable|file|mimes:jpg,png,jpeg|max:2048',
        ]);

        // Handle file upload if provided
        if ($request->hasFile('image_path')) {
            $filePath = $request->file('image_path')->store('leave_images', 'public');
            $validatedData['image_path'] = $filePath;
        }

        $validatedData['company_id'] = $company->id;

        $leaveRequest = LeaveRequest::create($validatedData);

        return response()->json($leaveRequest, 201);
    }

    public function update(Request $request, $companyCode, $id)
    {
        // Fetch the company by company_code
        $company = Company::where('company_code', $companyCode)->first();

        if (!$company) {
            return response()->json(['error' => 'Company not found'], 404);
        }

        // Fetch the leave request by ID
        $leaveRequest = LeaveRequest::find($id);

        if (!$leaveRequest) {
            return response()->json(['message' => 'Leave request not found'], 404);
        }

        // Validate the request
        $validated = $request->validate([
            'leave_type_id' => 'required|exists:leave_types,id',
            'start_date' => 'required|date',
            'end_date' => 'required|date|after_or_equal:start_date',
            'status' => 'required|in:Pending,Approved,Rejected', // Adjust casing to match database
            'reason' => 'nullable|string|max:255',
            'image' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
        ]);

        // Check if the user belongs to the specified company
        $user = User::where('id', $leaveRequest->user_id)
                    ->where('company_id', $company->id)
                    ->first();

        if (!$user) {
            return response()->json(['error' => 'User does not belong to the specified company'], 404);
        }

        // Handle image upload (if exists)
        $imagePath = $leaveRequest->image_path;

        if ($request->hasFile('image')) {
            // Delete the old image if it exists
            if ($imagePath && Storage::exists('public/' . $imagePath)) {
                Storage::delete('public/' . $imagePath);
            }

            // Store the new image
            $imagePath = $request->file('image')->store('leave_requests', 'public');
        }

        // Update leave request
        $leaveRequest->update([
            'leave_type_id' => $validated['leave_type_id'],
            'start_date' => $validated['start_date'],
            'end_date' => $validated['end_date'],
            'status' => $validated['status'],
            'reason' => $validated['reason'],
            'image_path' => $imagePath,
        ]);

        return response()->json($leaveRequest);
    }

    // Delete a leave request
    public function destroy($companyCode, $id)
    {
        // Fetch the company by company_code
        $company = Company::where('company_code', $companyCode)->first();

        // Check if the company exists
        if (!$company) {
            return response()->json(['error' => 'Company not found'], 404);
        }

        // Find the leave request
        $leaveRequest = LeaveRequest::find($id);
        if (!$leaveRequest) {
            return response()->json(['message' => 'Leave request not found'], 404);
        }

        // Check if the user belongs to the company
        $user = User::where('id', $leaveRequest->user_id)
                    ->where('company_id', $company->id)
                    ->first();

        if (!$user) {
            return response()->json(['error' => 'User does not belong to the specified company'], 404);
        }

        // Delete the image if it exists
        if ($leaveRequest->image_path && Storage::exists('public/' . $leaveRequest->image_path)) {
            Storage::delete('public/' . $leaveRequest->image_path);
        }

        // Delete the leave request
        $leaveRequest->delete();

        return response()->json(['message' => 'Leave request deleted successfully']);
    }





}
